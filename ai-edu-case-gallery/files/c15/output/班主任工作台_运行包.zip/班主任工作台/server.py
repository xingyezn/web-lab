"""Local classroom practice app. Python 3.10+, standard library only."""
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from http.cookies import SimpleCookie
from pathlib import Path
from datetime import datetime,timezone,timedelta,date
from contextlib import contextmanager
import argparse,sqlite3,json,secrets,hashlib,hmac,time,threading,re,webbrowser
ROOT=Path(__file__).resolve().parent;TODAY=lambda:datetime.now(timezone(timedelta(hours=8))).date().isoformat()
def uid():return secrets.token_hex(8)
def password_hash(password,salt):return hashlib.pbkdf2_hmac('sha256',password.encode(),bytes.fromhex(salt),600000).hex()
def fresh(sample=False):
 d=dict(class_name='五年级1班',students=[],attendance={},homework=[],tasks=[],communications=[])
 if sample:
  for i in range(8):d['students'].append(dict(id=uid(),code=str(50101+i),name='模拟学生'+str(i+1),guardian='',contact='',note=''))
  d['homework']=[dict(id=uid(),title='My School Day 阅读练习',subject='英语',due=TODAY(),status={s['id']:('已交' if i<5 else '待订正' if i==5 else '未交') for i,s in enumerate(d['students'])})]
  d['tasks']=[dict(id=uid(),title='整理本周班级阅读记录',due=TODAY(),done=False),dict(id=uid(),title='准备家长开放日课堂展示',due=TODAY(),done=False)]
 return d
class Bad(Exception):pass
def text(v,key,maxlen=200,required=False):
 value=v.get(key,'')
 if not isinstance(value,str):raise Bad('请检查输入内容。')
 if key not in ['password','old']:value=value.strip()
 if required and not value.strip():raise Bad('请填写必填内容。')
 if len(value)>maxlen:raise Bad('输入内容过长。')
 return value
def day(v):
 try:return date.fromisoformat(v).isoformat()
 except (TypeError,ValueError):raise Bad('请选择有效日期。')
def find(rows,id):
 for row in rows:
  if row['id']==id:return row
 raise Bad('记录不存在，请刷新后重试。')
class Handler(BaseHTTPRequestHandler):
 server_version='ClassroomPractice'
 def log_message(self,*args):pass
 def valid_host(self):return self.headers.get('Host') in self.server.allowed_hosts
 @contextmanager
 def db(self):
  c=sqlite3.connect(self.server.database,timeout=10);c.row_factory=sqlite3.Row
  try:
   with c:yield c
  finally:c.close()
 def reply(self,obj,status=200,cookie=None):
  raw=json.dumps(obj,ensure_ascii=False).encode();self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.send_header('Content-Length',str(len(raw)))
  if cookie:self.send_header('Set-Cookie',cookie)
  self.end_headers();self.wfile.write(raw)
 def session(self,c):
  cookie=SimpleCookie()
  try:cookie.load(self.headers.get('Cookie',''));token=cookie['class_session'].value
  except Exception:return None
  return c.execute('SELECT users.* FROM sessions JOIN users ON users.id=sessions.user_id WHERE sessions.token=? AND sessions.expires>?',(hashlib.sha256(token.encode()).hexdigest(),time.time())).fetchone()
 def cookie(self,token,maxage=43200):return 'class_session='+token+'; HttpOnly; SameSite=Strict; Path=/; Max-Age='+str(maxage)
 def do_GET(self):
  if not self.valid_host():return self.reply({'error':'访问地址不匹配。'},403)
  if self.path in ['/api/state','/api/export']:
   with self.db() as c:
    user=self.session(c)
    if not user:return self.reply({'error':'请先登录。'},401)
    d=json.loads(user['data']);return self.reply(dict(user=user['username'],today=TODAY(),data=d))
  files={'/':('index.html','text/html; charset=utf-8'),'/app.js':('app.js','text/javascript; charset=utf-8'),'/app.css':('app.css','text/css; charset=utf-8')}
  if self.path not in files:return self.reply({'error':'页面不存在。'},404)
  name,typ=files[self.path];raw=(ROOT/name).read_bytes();self.send_response(200);self.send_header('Content-Type',typ);self.send_header('Content-Length',str(len(raw)));self.send_header('X-Content-Type-Options','nosniff');self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; object-src 'none'; frame-ancestors 'none'; base-uri 'none'");self.end_headers();self.wfile.write(raw)
 def do_POST(self):
  if not self.valid_host() or self.headers.get('Origin') not in self.server.origins:return self.reply({'error':'请从工作台页面发起操作。'},403)
  if self.headers.get('Content-Type','').split(';')[0]!='application/json':return self.reply({'error':'请求格式错误。'},415)
  try:
   length=int(self.headers.get('Content-Length','0'))
   if not 0<length<200000:return self.reply({'error':'请求大小不合适。'},400)
   v=json.loads(self.rfile.read(length))
   if not isinstance(v,dict):raise Bad('请求格式错误。')
   if self.path in ['/api/register','/api/login']:return self.auth(v)
   with self.db() as c:
    c.execute('BEGIN IMMEDIATE');user=self.session(c)
    if not user:return self.reply({'error':'登录已过期，请重新登录。'},401)
    if self.path=='/api/logout':
     cookie=SimpleCookie(self.headers.get('Cookie',''));c.execute('DELETE FROM sessions WHERE token=?',(hashlib.sha256(cookie['class_session'].value.encode()).hexdigest(),));return self.reply({'ok':True},cookie=self.cookie('',0))
    if self.path=='/api/password':
     if not hmac.compare_digest(password_hash(text(v,'old',256),user['salt']),user['password']):raise Bad('原密码不正确。')
     new=text(v,'password',256)
     if len(new)<8:raise Bad('新密码至少8位。')
     salt=secrets.token_hex(16);c.execute('UPDATE users SET salt=?,password=? WHERE id=?',(salt,password_hash(new,salt),user['id']));c.execute('DELETE FROM sessions WHERE user_id=?',(user['id'],));return self.reply({'ok':True},cookie=self.cookie('',0))
    if self.path!='/api/update':return self.reply({'error':'接口不存在。'},404)
    d=json.loads(user['data']);action=v.get('action');id=v.get('id')
    if action=='student':
     code=text(v,'code',30,True);name=text(v,'name',40,True)
     if any(x['code']==code and x['id']!=id for x in d['students']):raise Bad('这个学号已存在。')
     row=find(d['students'],id) if id else dict(id=uid());row.update(code=code,name=name,guardian=text(v,'guardian',40),contact=text(v,'contact',80),note=text(v,'note',500))
     if not id:
      if len(d['students'])>=1000:raise Bad('本地练习版最多保存1000名学生。')
      d['students'].append(row)
    elif action=='remove_student':
     find(d['students'],id);d['students']=[x for x in d['students'] if x['id']!=id]
     for records in d['attendance'].values():records.pop(id,None)
     for hw in d['homework']:hw['status'].pop(id,None)
     d['communications']=[x for x in d['communications'] if x['student_id']!=id]
    elif action=='attendance':
     key=day(v.get('date'));records=v.get('records')
     if not isinstance(records,dict):raise Bad('考勤内容错误。')
     allowed={s['id'] for s in d['students']}
     if any(k not in allowed or status not in ['出勤','迟到','请假','缺勤'] for k,status in records.items()):raise Bad('考勤记录无效。')
     d['attendance'].setdefault(key,{}).update(records)
    elif action=='homework':d['homework'].append(dict(id=uid(),title=text(v,'title',100,True),subject=text(v,'subject',30,True),due=day(v.get('due')),status={}))
    elif action=='homework_status':
     hw=find(d['homework'],id);sid=v.get('student_id');find(d['students'],sid);status=v.get('status')
     if status not in ['已交','未交','待订正']:raise Bad('作业状态错误。')
     hw['status'][sid]=status
    elif action=='task':d['tasks'].append(dict(id=uid(),title=text(v,'title',120,True),due=day(v.get('due')),done=False))
    elif action=='task_toggle':find(d['tasks'],id)['done']=bool(v.get('done'))
    elif action=='communication':
     sid=v.get('student_id');find(d['students'],sid);d['communications'].append(dict(id=uid(),student_id=sid,date=day(v.get('date')),channel=text(v,'channel',30,True),content=text(v,'content',1000,True),followup=text(v,'followup',500)))
    elif action=='settings':d['class_name']=text(v,'class_name',50,True)
    else:raise Bad('操作不存在。')
    c.execute('UPDATE users SET data=? WHERE id=?',(json.dumps(d,ensure_ascii=False),user['id']))
   return self.reply({'ok':True})
  except (Bad,ValueError,json.JSONDecodeError) as e:return self.reply({'error':str(e) if isinstance(e,Bad) else '请检查输入格式。'},400)
  except sqlite3.IntegrityError:return self.reply({'error':'用户名已存在，请换一个。'},409)
  except Exception:return self.reply({'error':'暂时无法保存，请稍后重试。'},500)
 def auth(self,v):
  now=time.time();key=self.client_address[0]
  with self.server.limit_lock:
   attempts=[t for t in self.server.limits.get(key,[]) if now-t<60]
   if len(attempts)>=20:return self.reply({'error':'尝试次数较多，请一分钟后再试。'},429)
   attempts.append(now);self.server.limits[key]=attempts
  username=text(v,'username',24,True);password=text(v,'password',256,True)
  if not re.fullmatch(r'[\w-]{3,24}',username):raise Bad('用户名需为3—24位字母、数字、中文或下划线。')
  with self.db() as c:
   if self.path=='/api/register':
    if len(password)<8:raise Bad('密码至少8位。')
    salt=secrets.token_hex(16);d=fresh(v.get('sample') is True);cur=c.execute('INSERT INTO users(username,salt,password,data) VALUES(?,?,?,?)',(username,salt,password_hash(password,salt),json.dumps(d,ensure_ascii=False)));user_id=cur.lastrowid
   else:
    user=c.execute('SELECT * FROM users WHERE username=?',(username,)).fetchone();salt=user['salt'] if user else '00'*16;expected=user['password'] if user else '0'*64
    if not hmac.compare_digest(password_hash(password,salt),expected):return self.reply({'error':'用户名或密码不正确。'},401)
    user_id=user['id']
   token=secrets.token_urlsafe(32);c.execute('DELETE FROM sessions WHERE expires<?',(now,));c.execute('INSERT INTO sessions VALUES(?,?,?)',(hashlib.sha256(token.encode()).hexdigest(),user_id,now+43200))
  return self.reply({'ok':True},cookie=self.cookie(token))
def run():
 p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=8835);p.add_argument('--data-dir',type=Path,default=ROOT/'data');p.add_argument('--open',action='store_true');a=p.parse_args();a.data_dir.mkdir(parents=True,exist_ok=True);db=a.data_dir/'classroom.sqlite3'
 with sqlite3.connect(db) as c:
  c.execute('CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,username TEXT UNIQUE,salt TEXT,password TEXT,data TEXT)');c.execute('CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,user_id INTEGER,expires REAL)')
 server=ThreadingHTTPServer(('127.0.0.1',a.port),Handler);server.database=db;server.allowed_hosts={f'127.0.0.1:{a.port}',f'localhost:{a.port}'};server.origins={'http://'+h for h in server.allowed_hosts};server.limits={};server.limit_lock=threading.Lock();url=f'http://127.0.0.1:{a.port}/';print('Classroom workspace: '+url,flush=True)
 if a.open:threading.Timer(.5,lambda:webbrowser.open(url)).start()
 try:server.serve_forever()
 except KeyboardInterrupt:pass
 finally:server.server_close()
if __name__=='__main__':run()
