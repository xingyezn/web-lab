@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel% equ 0 (
  py -3 server.py --open
) else (
  python server.py --open
)
echo.
echo 工作台已停止。如未启动，请确认已安装Python 3.10或以上。
pause
